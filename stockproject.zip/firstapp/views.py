from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'index.html')
from django.http import HttpResponse
from django.template import loader
  
def index(request):
    return render(request,'index.html')